import { models } from './models.js';

describe('models', () => {
  it('should work', () => {
    expect(models()).toEqual('models');
  });
});
